"use client";

import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { QRCodeSVG } from "qrcode.react";
import { toast } from "sonner";

interface QrAccessDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  localUrl: string;
  secureUrl: string;
}

export function QrAccessDialog({ open, onOpenChange, localUrl, secureUrl }: QrAccessDialogProps) {
  // Por defecto mostrar HTTPS (necesario para camara en movil)
  const [showSecure, setShowSecure] = useState(true);
  const activeUrl = showSecure ? secureUrl : localUrl;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle className="text-center">Acceso Movil via QR</DialogTitle>
        </DialogHeader>
        <div className="flex flex-col items-center gap-4 py-4">
          <p className="text-sm text-muted-foreground text-center">
            Escanea este codigo con la camara de tu telefono para acceder al TPV desde cualquier dispositivo.
          </p>

          {/* Toggle HTTPS / HTTP */}
          <div className="flex gap-1 p-1 bg-muted rounded-lg">
            <button
              onClick={() => setShowSecure(true)}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                showSecure ? "bg-green-600 text-white shadow-sm" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              🔒 HTTPS (Recomendado)
            </button>
            <button
              onClick={() => setShowSecure(false)}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                !showSecure ? "bg-primary text-white shadow-sm" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              🌐 HTTP (Local IP)
            </button>
          </div>

          {showSecure && (
            <div className="bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800 rounded-lg p-2 w-full">
              <p className="text-[10px] text-green-700 dark:text-green-400 text-center font-medium">
                ✅ Modo HTTPS: La camara del telefono funcionara para escanear codigos de barras y tomar fotos de productos.
              </p>
            </div>
          )}
          {!showSecure && (
            <div className="bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800 rounded-lg p-2 w-full">
              <p className="text-[10px] text-amber-700 dark:text-amber-400 text-center font-medium">
                ⚠️ Modo HTTP: La camara del telefono NO funcionara para escanear codigos. Use HTTPS para acceso completo.
              </p>
            </div>
          )}

          {activeUrl ? (
            <>
              <div className="p-4 bg-white rounded-xl border-2 shadow-sm">
                <QRCodeSVG value={activeUrl} size={200} level="H" includeMargin={false} />
              </div>
              <div className="text-center space-y-2 w-full">
                <p className="text-xs text-muted-foreground">Direccion de acceso:</p>
                <div className="flex items-center gap-2 p-2 bg-muted rounded-lg">
                  <code className="flex-1 text-sm font-mono font-bold truncate">{activeUrl}</code>
                  <Button variant="outline" size="sm" className="h-8 text-xs flex-shrink-0"
                    onClick={() => { navigator.clipboard.writeText(activeUrl); toast.success("URL copiada al portapapeles"); }}>
                    Copiar
                  </Button>
                </div>
                <p className="text-[11px] text-muted-foreground">
                  {showSecure
                    ? "Acceso via dominio local. Requiere Caddy ejecutandose."
                    : "Solo accesible desde dispositivos en la misma red WiFi/Local."}
                </p>
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center gap-2 py-8">
              <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
              <p className="text-sm text-muted-foreground">Detectando IP local...</p>
            </div>
          )}
          <Button variant="outline" className="w-full" onClick={() => onOpenChange(false)}>Cerrar</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
