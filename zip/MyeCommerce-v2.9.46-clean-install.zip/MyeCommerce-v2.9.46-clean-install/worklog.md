---
Task ID: 1
Agent: Super Z (Main)
Task: Fix 6 bugs criticos reportados por el usuario - v2.9.44

Work Log:
- Analizadas 7 capturas de pantalla del usuario con VLM
- Clonado repositorio y leidos todos los archivos criticos
- Diagnosticados 6 bugs con causa raiz:

BUG 1: API /api/products/upload ELIMINADA en v2.9.43
- Causa: commit 586f0d6 elimino el archivo por error
- Fix: Restaurada desde git history (commit b219551)

BUG 2: Exportar clientes - error Prisma
- Causa: whereClause.active = true pero schema usa isActive
- Fix: Cambiado a whereClause.isActive = true

BUG 3: ShortcutsBar no renderizada en POS
- Causa: Componente importado en pos-tab.tsx pero nunca renderizado
- Fix: Agregada al cart-panel.tsx (dentro del CardContent)

BUG 4: Marcas/Categorias no funcionan
- Causa RAIZ: Tabla Brand NUNCA fue migrada a la BD
- La unica migracion (20260811133522) NO incluye Brand
- Fix: Creada migracion SQL completa + cambiado INICIAR-MYECCOMMERCE.bat
  para ejecutar prisma db push SIEMPRE (no solo si dev.db no existe)

BUG 5: Mejorados mensajes de error en APIs brands/categories

BUG 6: Catalogo imagenes - ya estaba fixeado en v2.9.43 (object-fit:contain)

Stage Summary:
- Build pasa limpio (next build)
- Commit: 6df5469 v2.9.44
- Push: exitoso a origin/main
- Tag: v2.9.44 creado y pusheado
- 7 archivos modificados, 318 lineas agregadas, 88 eliminadas

---
Task ID: 1
Agent: Main Agent
Task: v2.9.47 - Fix categories, menus, QR, license, header layout

Work Log:
- Fixed categories API route: changed NextResponse.json(data, 201) to {status:201} format, added _count include
- Fixed createCategory in products-tab.tsx: parse JSON before checking r.ok, update local state immediately
- Fixed createBrand in products-tab.tsx: same pattern fix
- Removed duplicate TabsList desktop nav bar (lines 523-541 in page.tsx) — AppNav sidebar handles all navigation
- Restored QR dialog with HTTPS/HTTP toggle, HTTPS defaults to https://myecommerce.ve
- Removed always-visible green license banner from main page
- Added amber warning banner only when license expires in <=30 days
- Reorganized header into 2 rows: Row 1 (menu + store name/address + BCV rate), Row 2 (date/time + user + logout)
- Built successfully, committed as v2.9.47, pushed to main
- Created GitHub release v2.9.47 with clean install ZIP

Stage Summary:
- Version: v2.9.47
- Release ZIP: https://github.com/csglider/MyeCommerce-v2.9.20/releases/download/v2.9.47/MyeCommerce-v2.9.47-clean-install.zip
- All 5 fixes applied and verified
