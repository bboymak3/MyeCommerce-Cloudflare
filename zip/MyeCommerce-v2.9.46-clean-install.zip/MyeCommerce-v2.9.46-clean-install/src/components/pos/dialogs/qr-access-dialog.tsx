"use client";

import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { QRCodeSVG } from "qrcode.react";
import { toast } from "sonner";

interface QrAccessDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  localUrl: string;
}

export function QrAccessDialog({ open, onOpenChange, localUrl }: QrAccessDialogProps) {
  // Build HTTPS URL from the HTTP local URL
  const httpsUrl = localUrl ? localUrl.replace("http://", "https://") : "";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle className="text-center">Acceso Movil via QR</DialogTitle>
        </DialogHeader>
        <div className="flex flex-col items-center gap-4 py-4">
          <p className="text-sm text-muted-foreground text-center">
            Escanea este codigo con la camara de tu telefono para acceder al TPV desde cualquier dispositivo de la red WiFi.
          </p>

          {/* HTTPS info banner */}
          <div className="w-full p-3 bg-green-50 border border-green-200 rounded-lg">
            <p className="text-xs text-green-800 font-medium text-center">
              Modo HTTPS activo — La camara del telefono podra escanear codigos de barra y tomar fotos de productos.
            </p>
          </div>

          {httpsUrl ? (
            <>
              <div className="p-4 bg-white rounded-xl border-2 shadow-sm">
                <QRCodeSVG value={httpsUrl} size={200} level="H" includeMargin={false} />
              </div>
              <div className="text-center space-y-2 w-full">
                <p className="text-xs text-muted-foreground">Direccion de acceso:</p>
                <div className="flex items-center gap-2 p-2 bg-muted rounded-lg">
                  <code className="flex-1 text-sm font-mono font-bold truncate">{httpsUrl}</code>
                  <Button variant="outline" size="sm" className="h-8 text-xs flex-shrink-0"
                    onClick={() => { navigator.clipboard.writeText(httpsUrl); toast.success("URL copiada al portapapeles"); }}>
                    Copiar
                  </Button>
                </div>

                {/* First-time certificate instructions */}
                <div className="mt-3 p-3 bg-amber-50 border border-amber-200 rounded-lg">
                  <p className="text-xs font-bold text-amber-800 text-center mb-1">PRIMERA VEZ DESDE EL TELEFONO:</p>
                  <div className="text-[11px] text-amber-700 space-y-0.5 text-left">
                    <p>1. Escanea el QR o abre la URL de arriba</p>
                    <p>2. El navegador muestra &quot;Conexion no segura&quot;</p>
                    <p>3. Toca <strong>&quot;Avanzado&quot;</strong></p>
                    <p>4. Toca <strong>&quot;Ir al sitio (inseguro)&quot;</strong></p>
                    <p className="text-amber-600 font-medium mt-1">Solo se hace UNA VEZ. Despues funciona siempre.</p>
                  </div>
                </div>

                <p className="text-[11px] text-muted-foreground">
                  Funciona con cualquier dispositivo conectado a la misma red WiFi. No requiere configuracion adicional.
                </p>
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center gap-2 py-8">
              <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
              <p className="text-sm text-muted-foreground">Detectando IP local...</p>
            </div>
          )}
          <Button variant="outline" className="w-full" onClick={() => onOpenChange(false)}>Cerrar</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
